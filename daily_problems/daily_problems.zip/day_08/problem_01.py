from typing import List, Dict


# Day 8 - Problem 1
# Topic: Sensor aggregation
#
# Task:
# Given sensor readings, return a dictionary:
# sensor -> average reading
#
# Important:
# - compute average using all readings for the same sensor
# - return averages as floats
# - return {} for empty input
#
# What to return:
# - one dictionary mapping each sensor name to its average value
#
# Expected output for current sample:
# {"temp": 37.0, "hum": 45.0, "dist": 105.0}


readings = [
    {"sensor": "temp", "value": 36.5},
    {"sensor": "hum", "value": 45.0},
    {"sensor": "temp", "value": 37.5},
    {"sensor": "dist", "value": 100.0},
    {"sensor": "dist", "value": 110.0},
]


def average_sensor_values(readings: List[Dict]) -> Dict[str, float]:
    # TODO
    pass


if __name__ == "__main__":
    print(average_sensor_values(readings))
